
<div class="btn-widget design-<?php echo $buttonstyle; ?><?php echo $showcount ? ' count' : ''; ?>">
<?php if ( $showcount ) : ?>
	<div class="btn-count"><i></i><u></u><a><?php echo mailster( 'subscribers' )->get_count( 'kilo', 1, true ) ?></a></div>
<?php endif; ?>
	<a class="btn" title="<?php echo esc_attr( $buttonlabel ) ?>"><?php echo esc_html( $buttonlabel ) ?></a>
</div>
