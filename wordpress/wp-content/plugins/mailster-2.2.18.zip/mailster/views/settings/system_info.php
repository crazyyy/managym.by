<p class="description"><?php printf( __( 'Please check out %s if you have problems with the plugin', 'mailster' ), '<a href="https://rxa.li/support?utm_source=Mailster+System+Info+Page" class="external">' . __( 'our Knowledge base', 'mailster' ) . '</a>' ); ?></p>
<textarea id="system_info_content" readonly class="code">
</textarea>
<p class="description"><?php esc_html_e( 'To copy the system info, click below then press Ctrl + C (PC) or Cmd + C (Mac).', 'mailster' );?></p>
